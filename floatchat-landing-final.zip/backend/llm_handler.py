import os
import re
from typing import Optional
import logging
from openai import OpenAI

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LLMHandler:
    def __init__(self):
        """Initialize the LLM handler with OpenAI client."""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            logger.warning("OPENAI_API_KEY not found. LLM functionality will be limited.")
            self.client = None
        else:
            self.client = OpenAI(api_key=api_key)
    
    def parse_user_query(self, user_message: str) -> str:
        """
        Parse user query to extract Argo float ID using LLM.
        
        Args:
            user_message: Natural language query from user
            
        Returns:
            Float ID as string, or "ERROR" if not found
        """
        try:
            # First, try regex pattern matching for common float ID formats
            float_id = self._extract_float_id_regex(user_message)
            if float_id != "ERROR":
                return float_id
            
            # If regex fails and we have OpenAI, use LLM
            if self.client:
                return self._extract_float_id_llm(user_message)
            else:
                logger.warning("No OpenAI client available, falling back to regex only")
                return "ERROR"
                
        except Exception as e:
            logger.error(f"Error parsing user query: {e}")
            return "ERROR"
    
    def _extract_float_id_regex(self, user_message: str) -> str:
        """Extract float ID using regex patterns."""
        # Common patterns for Argo float IDs (typically 7 digits)
        patterns = [
            r'\b(\d{7})\b',  # 7-digit number
            r'float\s+(\d{4,8})',  # "float" followed by number
            r'id\s*:?\s*(\d{4,8})',  # "id" followed by number
            r'#(\d{4,8})',  # hashtag followed by number
        ]
        
        for pattern in patterns:
            match = re.search(pattern, user_message, re.IGNORECASE)
            if match:
                float_id = match.group(1)
                logger.info(f"Extracted float ID using regex: {float_id}")
                return float_id
        
        return "ERROR"
    
    def _extract_float_id_llm(self, user_message: str) -> str:
        """Extract float ID using OpenAI LLM."""
        system_prompt = """You are an expert oceanographer AI assistant. Your task is to extract Argo float IDs from user messages.

Argo float IDs are typically 7-digit numbers (e.g., 2902743, 5904471).

Rules:
1. Extract ONLY the numeric Argo float ID from the user's message
2. Return ONLY the number, nothing else
3. If no valid float ID is found, return exactly "ERROR"
4. Do not include any explanation or additional text

Examples:
- "Show me temperature data for float 2902743" → "2902743"
- "What's the profile for 5904471?" → "5904471"
- "Tell me about ocean temperatures" → "ERROR"
"""

        try:
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ],
                max_tokens=50,
                temperature=0
            )
            
            result = response.choices[0].message.content.strip()
            
            # Validate that result is a number or ERROR
            if result == "ERROR" or (result.isdigit() and len(result) >= 4):
                logger.info(f"LLM extracted float ID: {result}")
                return result
            else:
                logger.warning(f"LLM returned invalid result: {result}")
                return "ERROR"
                
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return "ERROR"
    
    def generate_response_text(self, float_id: str, data: dict) -> str:
        """Generate natural language response about the float data."""
        if "error" in data:
            return f"I'm sorry, I couldn't retrieve data for Argo float {float_id}. {data['error']}"
        
        num_points = data.get("num_points", 0)
        temp_range = ""
        if data.get("temperature"):
            temps = data["temperature"]
            temp_range = f"Temperature ranges from {min(temps):.1f}°C to {max(temps):.1f}°C."
        
        return f"Here is the profile data for Argo float {float_id}. The profile contains {num_points} data points. {temp_range}"

# Global instance
llm_handler = LLMHandler()

def parse_user_query(user_message: str) -> str:
    """Convenience function to parse user queries."""
    return llm_handler.parse_user_query(user_message)

def generate_response_text(float_id: str, data: dict) -> str:
    """Convenience function to generate response text."""
    return llm_handler.generate_response_text(float_id, data)
