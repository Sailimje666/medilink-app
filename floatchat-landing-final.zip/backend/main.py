from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any
import logging

from data_manager import get_argo_profile
from llm_handler import parse_user_query, generate_response_text

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="FloatChat API",
    description="AI-powered oceanographic data analysis system for Argo floats",
    version="1.0.0"
)

# Add CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    text: str
    data: Dict[str, Any]

class FloatDataResponse(BaseModel):
    float_id: str
    data: Dict[str, Any]

@app.get("/")
async def root():
    """Health check endpoint."""
    return {"message": "FloatChat API is running", "status": "healthy"}

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Main chat endpoint that processes natural language queries about Argo floats.
    
    Args:
        request: ChatRequest containing the user's message
        
    Returns:
        ChatResponse with text explanation and visualization data
    """
    try:
        user_message = request.message
        logger.info(f"Received chat request: {user_message}")
        
        # Parse the user query to extract float ID
        float_id = parse_user_query(user_message)
        
        if float_id == "ERROR":
            return ChatResponse(
                text="I couldn't find a valid Argo float ID in your message. Please specify a float ID (e.g., 'Show me data for float 2902743').",
                data={
                    "type": "error",
                    "message": "No float ID found"
                }
            )
        
        # Get the float data
        float_data = get_argo_profile(float_id)
        
        if "error" in float_data:
            return ChatResponse(
                text=f"I encountered an error retrieving data for float {float_id}: {float_data['error']}",
                data={
                    "type": "error",
                    "message": float_data["error"]
                }
            )
        
        # Generate natural language response
        response_text = generate_response_text(float_id, float_data)
        
        # Format data for visualization
        viz_data = {
            "type": "profile",
            "float_id": float_id,
            "values": {
                "pressure": float_data["pressure"],
                "temperature": float_data["temperature"],
                "salinity": float_data["salinity"]
            },
            "metadata": {
                "num_points": float_data["num_points"]
            }
        }
        
        return ChatResponse(
            text=response_text,
            data=viz_data
        )
        
    except Exception as e:
        logger.error(f"Error in chat endpoint: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/float/{float_id}", response_model=FloatDataResponse)
async def get_float_data(float_id: str):
    """
    Direct API endpoint to get profile data for a specific float ID.
    
    Args:
        float_id: The Argo float ID
        
    Returns:
        FloatDataResponse with the float data
    """
    try:
        logger.info(f"Received direct float request: {float_id}")
        
        # Validate float ID format (basic validation)
        if not float_id.isdigit() or len(float_id) < 4:
            raise HTTPException(status_code=400, detail="Invalid float ID format")
        
        # Get the float data
        float_data = get_argo_profile(float_id)
        
        if "error" in float_data:
            raise HTTPException(status_code=404, detail=float_data["error"])
        
        # Format response
        response_data = {
            "type": "profile",
            "float_id": float_id,
            "values": {
                "pressure": float_data["pressure"],
                "temperature": float_data["temperature"],
                "salinity": float_data["salinity"]
            },
            "metadata": {
                "num_points": float_data["num_points"]
            }
        }
        
        return FloatDataResponse(
            float_id=float_id,
            data=response_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in float endpoint: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint for monitoring."""
    return {
        "status": "healthy",
        "service": "FloatChat API",
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
