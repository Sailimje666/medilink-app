import { HeroSection } from "@/components/hero-section"
import { FeaturesSection } from "@/components/features-section"
import { InteractiveVisualization } from "@/components/interactive-visualization"
import { LiveChatDemo } from "@/components/live-chat-demo"
import { DashboardPreview } from "@/components/dashboard-preview"
import { ComparisonSection } from "@/components/comparison-section"
import { CallToActionSection } from "@/components/call-to-action-section"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <HeroSection />
      <FeaturesSection />
      <InteractiveVisualization />
      <LiveChatDemo />
      <DashboardPreview />
      <ComparisonSection />
      <CallToActionSection />
    </main>
  )
}
