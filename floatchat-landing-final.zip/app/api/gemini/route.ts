
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const message = body.message || "";
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "GEMINI_API_KEY not set in server env" }, { status: 500 });
    }

    // Basic proxy to Gemini (example endpoint). User must set GEMINI_API_KEY in environment.
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta2/models/text-bison-001:generateMessage", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        // This payload is illustrative. Adjust per Gemini API spec / model selected.
        prompt: {
          text: message
        },
        temperature: 0.2,
        maxOutputTokens: 512
      })
    });

    const data = await res.json();
    return NextResponse.json({ ok: true, data });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
