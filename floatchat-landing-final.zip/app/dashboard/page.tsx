
"use client"

import React from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function DashboardPage() {
  const router = useRouter()
  return (
    <main className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-7xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">FloatChat Dashboard</h1>
          <div>
            <Button onClick={() => router.push("/")}>Back to Home</Button>
          </div>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="p-4">
            <h2 className="text-lg font-semibold">Active Chats</h2>
            <p className="text-3xl mt-2">128</p>
          </Card>
          <Card className="p-4">
            <h2 className="text-lg font-semibold">Messages Today</h2>
            <p className="text-3xl mt-2">4,321</p>
          </Card>
          <Card className="p-4">
            <h2 className="text-lg font-semibold">Model</h2>
            <p className="text-3xl mt-2">Gemini</p>
          </Card>
        </section>

        <section className="mb-6 p-4 bg-card rounded-lg">
          <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
          <div className="flex gap-3">
            <Button onClick={() => alert('Start demo')}>Start Demo</Button>
            <Button onClick={() => alert('Settings')}>Settings</Button>
          </div>
        </section>

        <section className="p-4 bg-card rounded-lg">
          <h3 className="text-xl font-semibold mb-4">Recent Conversations</h3>
          <div className="space-y-3">
            <div className="p-3 bg-muted rounded">User: Show me sea temp</div>
            <div className="p-3 bg-muted rounded">User: What's the salinity?</div>
          </div>
        </section>
      </div>
    </main>
  )
}
