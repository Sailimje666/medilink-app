"use client"

import { Card } from "@/components/ui/card"
import { Waves, Thermometer, Droplets, Wind } from "lucide-react"
import { useEffect, useState } from "react"

const oceanLevels = [
  {
    depth: "Surface (0-200m)",
    icon: Waves,
    color: "from-primary/40 to-primary/20",
    data: ["Temperature", "Salinity", "Wave Height"],
  },
  {
    depth: "Mid-depth (200-1000m)",
    icon: Thermometer,
    color: "from-secondary/40 to-secondary/20",
    data: ["Temperature Gradients", "Current Velocity", "Nutrient Levels"],
  },
  {
    depth: "Deep Sea (1000m+)",
    icon: Droplets,
    color: "from-muted/40 to-muted/20",
    data: ["Pressure", "Oxygen Levels", "Deep Currents"],
  },
]

export function InteractiveVisualization() {
  const [activeLevel, setActiveLevel] = useState(0)
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="py-24 px-4 relative overflow-hidden">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Dive Into Ocean Data</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Experience a journey from surface to deep sea, exploring different data layers at each depth.
          </p>
        </div>

        <div className="relative">
          {/* Depth Indicator */}
          <div className="absolute left-4 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-secondary to-muted rounded-full" />

          <div className="space-y-12">
            {oceanLevels.map((level, index) => (
              <Card
                key={index}
                className={`ml-12 p-8 backdrop-blur-md bg-gradient-to-r ${level.color} border-primary/20 hover:border-primary/40 transition-all duration-500 cursor-pointer ${
                  activeLevel === index ? "scale-105 shadow-lg shadow-primary/20" : ""
                }`}
                onClick={() => setActiveLevel(index)}
              >
                <div className="flex items-center gap-6 mb-6">
                  <div className="p-4 rounded-full bg-primary/30">
                    <level.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{level.depth}</h3>
                    <p className="text-muted-foreground">Click to explore this depth level</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {level.data.map((dataType, dataIndex) => (
                    <div
                      key={dataIndex}
                      className="p-4 rounded-lg bg-background/20 backdrop-blur-sm border border-primary/20"
                    >
                      <h4 className="font-semibold mb-2">{dataType}</h4>
                      <div className="h-16 bg-gradient-to-r from-primary/30 to-secondary/30 rounded flex items-center justify-center">
                        <Wind className="w-6 h-6 text-primary animate-pulse" />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>

          {/* Floating ARGO Floats */}
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="absolute w-4 h-4 bg-primary rounded-full glow-animation"
              style={{
                right: `${10 + i * 8}%`,
                top: `${20 + i * 25}%`,
                transform: `translateY(${scrollY * 0.1 * (i + 1)}px)`,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
