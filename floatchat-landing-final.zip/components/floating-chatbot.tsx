
"use client"
import React, { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, MessageCircle } from "lucide-react"

export default function FloatingChatbot() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<{id:number, sender: 'user'|'bot', text:string}[]>([])
  const [text, setText] = useState("")

  async function sendMessage() {
    if (!text.trim()) return
    const userMsg = { id: Date.now(), sender: 'user', text }
    setMessages(prev => [...prev, userMsg])
    setText("")
    try {
      const res = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg.text })
      })
      const data = await res.json()
      const botText = data?.data?.candidates?.[0]?.content?.[0]?.text || data?.data?.output?.[0]?.content?.text || JSON.stringify(data)
      setMessages(prev => [...prev, { id: Date.now()+1, sender: 'bot', text: String(botText) }])
    } catch (e) {
      setMessages(prev => [...prev, { id: Date.now()+1, sender: 'bot', text: "Error contacting API" }])
    }
  }

  return (
    <div className="fixed right-6 bottom-6 z-50">
      <div className="w-80 bg-card rounded-lg shadow-lg overflow-hidden">
        <div className="p-2 flex items-center gap-2 border-b">
          <MessageCircle className="h-5 w-5" />
          <div className="font-medium">FloatChat</div>
          <div className="ml-auto">
            <Button size="sm" onClick={() => setOpen(o => !o)}>{open ? "Close" : "Open"}</Button>
          </div>
        </div>
        {open && (
          <div className="p-2">
            <div className="h-40 overflow-auto mb-2 space-y-2">
              {messages.map(m => (
                <div key={m.id} className={m.sender==='user' ? 'text-right' : 'text-left'}>
                  <div className={"inline-block p-2 rounded " + (m.sender==='user' ? 'bg-primary text-primary-foreground' : 'bg-muted')}>{m.text}</div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input value={text} onChange={(e:any)=>setText(e.target.value)} placeholder="Ask something..." />
              <Button onClick={sendMessage} size="icon"><Send className="h-4 w-4" /></Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
