"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { GraduationCap, Building2, Users, Map, BarChart3, Calendar } from "lucide-react"

export function DashboardPreview() {
  return (
    <section className="py-24 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Personalized Dashboards</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Tailored experiences for different user types with role-specific insights and visualizations.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="student" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-muted/30 backdrop-blur-md">
              <TabsTrigger value="student" className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4" />
                Student
              </TabsTrigger>
              <TabsTrigger value="policymaker" className="flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Policymaker
              </TabsTrigger>
              <TabsTrigger value="citizen" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Citizen
              </TabsTrigger>
            </TabsList>

            <TabsContent value="student">
              <Card className="backdrop-blur-md bg-card/60 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <GraduationCap className="w-6 h-6 text-primary" />
                    Student Dashboard - Learning Mode
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Interactive Map */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Map className="w-5 h-5 text-primary" />
                        <h3 className="font-semibold">Interactive Ocean Map</h3>
                      </div>
                      <div className="h-64 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg border border-primary/20 flex items-center justify-center relative overflow-hidden">
                        <div className="text-center">
                          <Map className="w-12 h-12 text-primary mx-auto mb-2" />
                          <p className="text-sm text-muted-foreground">Click regions to explore</p>
                        </div>
                        {/* Floating points */}
                        {[...Array(8)].map((_, i) => (
                          <div
                            key={i}
                            className="absolute w-2 h-2 bg-primary rounded-full animate-pulse"
                            style={{
                              left: `${20 + i * 10}%`,
                              top: `${30 + (i % 3) * 20}%`,
                            }}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Learning Modules */}
                    <div className="space-y-4">
                      <h3 className="font-semibold flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-primary" />
                        Learning Progress
                      </h3>
                      <div className="space-y-3">
                        {["Ocean Temperature Basics", "Salinity & Marine Life", "Climate Change Impact"].map(
                          (module, i) => (
                            <div key={i} className="p-3 bg-muted/20 rounded-lg border border-primary/10">
                              <div className="flex justify-between items-center mb-2">
                                <span className="text-sm font-medium">{module}</span>
                                <span className="text-xs text-primary">{85 - i * 15}%</span>
                              </div>
                              <div className="w-full bg-muted/30 rounded-full h-2">
                                <div
                                  className="bg-primary h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${85 - i * 15}%` }}
                                />
                              </div>
                            </div>
                          ),
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="policymaker">
              <Card className="backdrop-blur-md bg-card/60 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Building2 className="w-6 h-6 text-primary" />
                    Policymaker Dashboard - Strategic Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2">
                      <div className="flex items-center gap-2 mb-4">
                        <BarChart3 className="w-5 h-5 text-primary" />
                        <h3 className="font-semibold">Regional Impact Analysis</h3>
                      </div>
                      <div className="h-48 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg border border-primary/20 p-4">
                        <div className="grid grid-cols-2 gap-4 h-full">
                          {[
                            "Coastal Erosion Risk",
                            "Fishing Industry Impact",
                            "Tourism Sector Analysis",
                            "Climate Adaptation",
                          ].map((metric, i) => (
                            <div key={i} className="bg-background/30 rounded p-3 flex flex-col justify-between">
                              <span className="text-xs font-medium">{metric}</span>
                              <div className="text-2xl font-bold text-primary">{75 + i * 5}%</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-primary" />
                        Policy Alerts
                      </h3>
                      <div className="space-y-3">
                        {["High Temperature Alert", "Fishing Zone Update", "Coastal Protection"].map((alert, i) => (
                          <div key={i} className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                            <div className="text-sm font-medium text-destructive">{alert}</div>
                            <div className="text-xs text-muted-foreground mt-1">Requires attention</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="citizen">
              <Card className="backdrop-blur-md bg-card/60 border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Users className="w-6 h-6 text-primary" />
                    Citizen Dashboard - Local Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold mb-4 flex items-center gap-2">
                        <Map className="w-5 h-5 text-primary" />
                        Your Local Area
                      </h3>
                      <div className="h-48 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg border border-primary/20 p-4 relative">
                        <div className="absolute top-4 left-4 bg-background/80 rounded px-2 py-1 text-xs">
                          Mumbai Coast
                        </div>
                        <div className="h-full flex items-center justify-center">
                          <div className="text-center">
                            <div className="text-3xl font-bold text-primary mb-2">28°C</div>
                            <div className="text-sm text-muted-foreground">Current Water Temperature</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-4">Today's Conditions</h3>
                      <div className="space-y-3">
                        {[
                          { label: "Beach Safety", value: "Safe", color: "text-green-500" },
                          { label: "Water Quality", value: "Good", color: "text-primary" },
                          { label: "Wave Height", value: "1.2m", color: "text-secondary" },
                          { label: "UV Index", value: "High", color: "text-yellow-500" },
                        ].map((condition, i) => (
                          <div key={i} className="flex justify-between items-center p-3 bg-muted/20 rounded-lg">
                            <span className="text-sm">{condition.label}</span>
                            <span className={`text-sm font-medium ${condition.color}`}>{condition.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  )
}
