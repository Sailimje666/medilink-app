import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X } from "lucide-react"

const comparisons = [
  {
    feature: "Data Access",
    traditional: "Complex file downloads",
    floatchat: "Natural language queries",
  },
  {
    feature: "Visualization",
    traditional: "Manual plotting required",
    floatchat: "Auto-generated charts",
  },
  {
    feature: "Reports",
    traditional: "Static PDF documents",
    floatchat: "Interactive dashboards",
  },
  {
    feature: "Language Support",
    traditional: "English only",
    floatchat: "Hindi + English + Voice",
  },
  {
    feature: "User Experience",
    traditional: "Technical expertise needed",
    floatchat: "Accessible to everyone",
  },
  {
    feature: "Predictions",
    traditional: "Historical data only",
    floatchat: "ML-powered forecasts",
  },
]

export function ComparisonSection() {
  return (
    <section className="py-24 px-4 bg-gradient-to-b from-muted/20 to-background">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Why FloatChat is Different</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            See how FloatChat transforms the traditional approach to ocean data analysis.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="backdrop-blur-md bg-card/60 border-primary/20 overflow-hidden">
            <CardHeader className="text-center bg-gradient-to-r from-primary/10 to-secondary/10">
              <CardTitle className="text-2xl">Traditional Approach vs FloatChat</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                {/* Headers */}
                <div className="p-4 bg-muted/20 border-b border-primary/10">
                  <h3 className="font-semibold text-center">Feature</h3>
                </div>
                <div className="p-4 bg-muted/20 border-b border-primary/10 border-l border-primary/10">
                  <h3 className="font-semibold text-center flex items-center justify-center gap-2">
                    <X className="w-4 h-4 text-destructive" />
                    Traditional
                  </h3>
                </div>
                <div className="p-4 bg-primary/10 border-b border-primary/10 border-l border-primary/10">
                  <h3 className="font-semibold text-center flex items-center justify-center gap-2">
                    <Check className="w-4 h-4 text-green-500" />
                    FloatChat
                  </h3>
                </div>

                {/* Comparison Rows */}
                {comparisons.map((comparison, index) => (
                  <div key={index} className="contents">
                    <div className="p-4 border-b border-primary/10 bg-background/50">
                      <span className="font-medium">{comparison.feature}</span>
                    </div>
                    <div className="p-4 border-b border-primary/10 border-l border-primary/10 bg-background/30">
                      <div className="flex items-center gap-2">
                        <X className="w-4 h-4 text-destructive flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{comparison.traditional}</span>
                      </div>
                    </div>
                    <div className="p-4 border-b border-primary/10 border-l border-primary/10 bg-primary/5">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm font-medium">{comparison.floatchat}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
