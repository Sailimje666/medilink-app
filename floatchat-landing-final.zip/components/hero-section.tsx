"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MessageCircle, BarChart3 } from "lucide-react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Ocean Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background/90">
        <div className="absolute inset-0 opacity-30">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute w-full h-32 bg-gradient-to-r from-transparent via-primary/20 to-transparent wave-animation"
              style={{
                top: `${20 + i * 15}%`,
                animationDelay: `${i * 0.5}s`,
                transform: `rotate(${i % 2 === 0 ? 2 : -2}deg)`,
              }}
            />
          ))}
        </div>

        {/* Floating ARGO Floats */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 bg-primary rounded-full glow-animation float-animation"
            style={{
              left: `${10 + i * 12}%`,
              top: `${30 + (i % 3) * 20}%`,
              animationDelay: `${i * 0.8}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center">
        <div
          className={`transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
        >
          <h1 className="text-6xl md:text-8xl font-bold mb-6 text-balance">
            <span className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-primary [background-clip:text] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] supports-[background-clip:text]:text-transparent">
              FloatChat
            </span>
          </h1>
          <p className="text-2xl md:text-3xl mb-4 font-semibold">AI Meets the Oceans</p>
          <p className="text-lg md:text-xl mb-12 text-muted-foreground max-w-3xl mx-auto text-pretty">
            Ask in natural language. Explore, predict, and personalize ocean insights like never before.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button size="lg" className="text-lg px-8 py-6 glow-animation">
              Start Exploring
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="text-lg px-8 py-6 border-primary/50 hover:bg-primary/10 bg-transparent"
            >
              See Demo
            </Button>
          </div>
        </div>

        {/* Floating Chat Demo Panel */}
        <Card className="max-w-md mx-auto p-6 backdrop-blur-md bg-card/60 border-primary/30 float-animation">
          <div className="flex items-center gap-3 mb-4">
            <MessageCircle className="w-5 h-5 text-primary" />
            <span className="text-sm font-medium">Live Demo</span>
          </div>
          <div className="space-y-3 text-left">
            <div className="bg-muted/30 rounded-lg p-3">
              <p className="text-sm">Show me temperature trends in Arabian Sea</p>
            </div>
            <div className="bg-primary/20 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                <span className="font-medium text-foreground">FloatChat AI</span>
              </div>
              <p className="text-sm">Here's your visualization 📊</p>
              <div className="mt-2 h-16 bg-gradient-to-r from-primary/30 to-secondary/30 rounded border border-primary/30 flex items-center justify-center">
                <span className="text-sm text-foreground">Interactive Chart</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  )
}
