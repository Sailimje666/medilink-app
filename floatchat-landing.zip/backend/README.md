# FloatChat Backend API

AI-powered oceanographic data analysis system for Argo floats.

## Setup Instructions

### 1. Install Dependencies

\`\`\`bash
cd backend
pip install -r requirements.txt
\`\`\`

### 2. Set Environment Variables

Create a `.env` file in the backend directory:

\`\`\`bash
# Required for LLM functionality
export OPENAI_API_KEY='your-openai-api-key-here'

# Optional: Custom cache directory
export ARGO_CACHE_DIR='./argo_cache'
\`\`\`

Or set them directly:

\`\`\`bash
export OPENAI_API_KEY='your-openai-api-key-here'
\`\`\`

### 3. Run the Server

\`\`\`bash
# Development mode with auto-reload
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production mode
uvicorn main:app --host 0.0.0.0 --port 8000
\`\`\`

The API will be available at `http://localhost:8000`

### 4. API Documentation

Once running, visit:
- Interactive docs: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## API Endpoints

### POST /chat
Main conversational endpoint for natural language queries.

**Request:**
\`\`\`json
{
  "message": "Show me the temperature profile for float 2902743"
}
\`\`\`

**Response:**
\`\`\`json
{
  "text": "Here is the profile data for Argo float 2902743...",
  "data": {
    "type": "profile",
    "float_id": "2902743",
    "values": {
      "pressure": [0, 10, 20, 30],
      "temperature": [25.1, 24.8, 23.5, 22.1],
      "salinity": [35.0, 35.1, 35.2, 35.3]
    }
  }
}
\`\`\`

### GET /float/{float_id}
Direct access to float data.

**Example:** `GET /float/2902743`

## Testing

Test the API with curl:

\`\`\`bash
# Health check
curl http://localhost:8000/health

# Chat endpoint
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"message": "Show me data for float 2902743"}'

# Direct float access
curl http://localhost:8000/float/2902743
\`\`\`

## Notes

- The current implementation uses mock data for demonstration
- To use real Argo data, implement proper data fetching in `data_manager.py`
- LLM functionality requires OpenAI API key
- Without OpenAI key, the system falls back to regex-based float ID extraction
