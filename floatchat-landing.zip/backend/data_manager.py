import os
import requests
import xarray as xr
import numpy as np
from typing import Dict, List, Optional
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ArgoDataManager:
    def __init__(self, cache_dir: str = "argo_cache"):
        """Initialize the Argo data manager with a cache directory."""
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
    def _get_cache_path(self, float_id: str) -> str:
        """Get the local cache path for a float ID."""
        return os.path.join(self.cache_dir, f"{float_id}.nc")
    
    def _download_float_data(self, float_id: str) -> bool:
        """
        Download Argo float data from NOAA NCEI.
        This is a simplified approach - in production, you'd need proper float ID to URL mapping.
        """
        try:
            # This is a placeholder URL structure - you'll need to implement proper URL construction
            # based on the actual Argo data organization
            base_url = "https://www.ncei.noaa.gov/data/oceans/argo/gadr/data"
            
            # For demo purposes, we'll create a mock NetCDF file with realistic structure
            logger.warning(f"Creating mock data for float {float_id} - implement actual download logic")
            
            # Create mock data that matches Argo float structure
            pressure = np.arange(0, 2000, 10)  # 0 to 2000 dbar
            temperature = 25 - (pressure / 100) + np.random.normal(0, 0.5, len(pressure))
            salinity = 35 + (pressure / 1000) + np.random.normal(0, 0.1, len(pressure))
            
            # Create xarray dataset with Argo-like structure
            ds = xr.Dataset({
                'PRES': (['N_PROF', 'N_LEVELS'], pressure.reshape(1, -1)),
                'TEMP': (['N_PROF', 'N_LEVELS'], temperature.reshape(1, -1)),
                'PSAL': (['N_PROF', 'N_LEVELS'], salinity.reshape(1, -1)),
            })
            
            cache_path = self._get_cache_path(float_id)
            ds.to_netcdf(cache_path)
            logger.info(f"Created mock data for float {float_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to download data for float {float_id}: {e}")
            return False
    
    def get_argo_profile(self, float_id: str) -> Dict:
        """
        Get Argo profile data for a specific float ID.
        
        Args:
            float_id: The Argo float ID (e.g., "2902743")
            
        Returns:
            Dictionary containing pressure, temperature, and salinity data
        """
        try:
            cache_path = self._get_cache_path(float_id)
            
            # Check if data exists in cache, if not download it
            if not os.path.exists(cache_path):
                logger.info(f"Float {float_id} not in cache, downloading...")
                if not self._download_float_data(float_id):
                    return {"error": f"Failed to download data for float {float_id}"}
            
            # Load the NetCDF file
            ds = xr.open_dataset(cache_path)
            
            # Extract the first profile (index 0)
            pressure = ds['PRES'].isel(N_PROF=0).values
            temperature = ds['TEMP'].isel(N_PROF=0).values
            salinity = ds['PSAL'].isel(N_PROF=0).values
            
            # Remove NaN values and quality control
            valid_mask = ~(np.isnan(pressure) | np.isnan(temperature) | np.isnan(salinity))
            
            pressure_clean = pressure[valid_mask].tolist()
            temperature_clean = temperature[valid_mask].tolist()
            salinity_clean = salinity[valid_mask].tolist()
            
            ds.close()
            
            return {
                "float_id": float_id,
                "pressure": pressure_clean,
                "temperature": temperature_clean,
                "salinity": salinity_clean,
                "num_points": len(pressure_clean)
            }
            
        except Exception as e:
            logger.error(f"Error processing float {float_id}: {e}")
            return {"error": f"Error processing float {float_id}: {str(e)}"}

# Global instance
argo_manager = ArgoDataManager()

def get_argo_profile(float_id: str) -> Dict:
    """Convenience function to get Argo profile data."""
    return argo_manager.get_argo_profile(float_id)
