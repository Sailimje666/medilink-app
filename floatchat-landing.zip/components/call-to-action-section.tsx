import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Rocket, Users, Shield } from "lucide-react"

export function CallToActionSection() {
  return (
    <section className="py-24 px-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/10 via-background to-background" />
      <div className="absolute inset-0 opacity-20">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-primary rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-balance">Ready to Explore the Oceans with AI?</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty mb-12">
            Join thousands of researchers, students, and ocean enthusiasts who are already using FloatChat to unlock
            ocean insights.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16">
            <Button
              size="lg"
              className="text-lg px-12 py-6 bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 glow-animation"
            >
              <Rocket className="w-5 h-5 mr-2" />
              Launch FloatChat
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="text-lg px-12 py-6 border-primary/50 hover:bg-primary/10 bg-transparent"
            >
              <Users className="w-5 h-5 mr-2" />
              Join Community
            </Button>
          </div>
        </div>

        {/* Partner Logos */}
        <Card className="max-w-2xl mx-auto p-8 backdrop-blur-md bg-card/60 border-primary/20 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-primary" />
            <span className="font-semibold">Supported by</span>
          </div>
          <div className="text-lg font-medium text-primary">Ministry of Earth Sciences, Government of India</div>
          <p className="text-sm text-muted-foreground mt-2">
            Empowering ocean research and education through AI innovation
          </p>
        </Card>

        {/* Floating Elements */}
        <div className="absolute top-1/4 left-10 w-16 h-16 bg-primary/20 rounded-full blur-xl animate-pulse" />
        <div
          className="absolute bottom-1/4 right-10 w-20 h-20 bg-secondary/20 rounded-full blur-xl animate-pulse"
          style={{ animationDelay: "1s" }}
        />
      </div>
    </section>
  )
}
