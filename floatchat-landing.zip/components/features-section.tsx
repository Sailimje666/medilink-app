"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Database, TrendingUp, Users, MapPin, Bell, Mic, Share2, BookOpen, Trophy, Moon, Eye } from "lucide-react"

const features = [
  {
    icon: Database,
    title: "Knowledge Vault",
    description: "Save and recall insights anytime with intelligent data storage.",
  },
  {
    icon: TrendingUp,
    title: "Future Predictions",
    description: "ML-powered ocean trend forecasts for informed decision making.",
  },
  {
    icon: Users,
    title: "User Modes",
    description: "Tailored dashboards for Students 👩‍🎓, Policymakers 🏛️, and Citizens 🌍.",
  },
  {
    icon: MapPin,
    title: "Geo Personalization",
    description: 'Region-focused dashboards (e.g., "Bay of Bengal insights").',
  },
  {
    icon: Bell,
    title: "Auto Alerts",
    description: "Anomaly detection for sudden changes in ocean conditions.",
  },
  {
    icon: Mic,
    title: "Voice & Local Language",
    description: "Ask in Hindi + English (voice or text) for accessibility.",
  },
  {
    icon: Share2,
    title: "Collaborative Insights",
    description: "Share dashboards with teams and friends for collective analysis.",
  },
  {
    icon: BookOpen,
    title: "Ocean Story Mode",
    description: 'Narrative "storytelling" view that turns data into timeline stories.',
  },
  {
    icon: Trophy,
    title: "Gamified Exploration",
    description: "Unlock badges when exploring different regions and depths.",
  },
  {
    icon: Moon,
    title: "Dark/Light Ocean Mode",
    description: "Switch between deep-sea dark theme and surface light theme.",
  },
  {
    icon: Eye,
    title: "Accessibility Mode",
    description: "Large fonts + high contrast for all users.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-24 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Powerful Features for Ocean Exploration</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Discover the comprehensive suite of AI-powered tools designed to make ocean data accessible to everyone.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="group hover:scale-105 transition-all duration-300 backdrop-blur-md bg-card/60 border-primary/20 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/20"
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 rounded-lg bg-primary/20 group-hover:bg-primary/30 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold">{feature.title}</h3>
                </div>
                <p className="text-muted-foreground text-pretty">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
