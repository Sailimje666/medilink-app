"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageCircle, BarChart3, Map, TrendingUp } from "lucide-react"
import { useState, useEffect } from "react"

const chatMessages = [
  {
    user: "Show me ocean temperature trends in Arabian Sea over 5 years",
    ai: "Here's your visualization 📊",
    chart: "temperature-trend",
  },
  {
    user: "What are the salinity levels near Mumbai coast?",
    ai: "Displaying salinity data for Mumbai coastal region 🗺️",
    chart: "salinity-map",
  },
  {
    user: "Predict oxygen levels for next month in Bay of Bengal",
    ai: "Based on ML analysis, here are the oxygen predictions 📈",
    chart: "oxygen-prediction",
  },
]

export function LiveChatDemo() {
  const [currentMessage, setCurrentMessage] = useState(0)
  const [isTyping, setIsTyping] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTyping(true)
      setTimeout(() => {
        setIsTyping(false)
        setCurrentMessage((prev) => (prev + 1) % chatMessages.length)
      }, 2000)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const getChartIcon = (chartType: string) => {
    switch (chartType) {
      case "temperature-trend":
        return TrendingUp
      case "salinity-map":
        return Map
      case "oxygen-prediction":
        return BarChart3
      default:
        return BarChart3
    }
  }

  return (
    <section className="py-24 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Natural Language Conversations</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Watch FloatChat understand and respond to complex ocean data queries in real-time.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="backdrop-blur-md bg-card/80 border-primary/30 shadow-2xl">
            <CardHeader className="border-b border-primary/20">
              <CardTitle className="flex items-center gap-3">
                <MessageCircle className="w-6 h-6 text-primary" />
                FloatChat AI Assistant
                <div className="ml-auto flex gap-1">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-muted-foreground">Online</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6 h-96 overflow-hidden">
                {/* User Message */}
                <div className="flex justify-end">
                  <div className="max-w-xs bg-primary/20 rounded-lg p-4">
                    <p className="text-sm">{chatMessages[currentMessage].user}</p>
                  </div>
                </div>

                {/* AI Response */}
                <div className="flex justify-start">
                  <div className="max-w-md bg-muted/30 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 bg-primary/30 rounded-full flex items-center justify-center">
                        <MessageCircle className="w-4 h-4 text-primary" />
                      </div>
                      <span className="text-sm font-medium">FloatChat AI</span>
                    </div>

                    {isTyping ? (
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                        <div
                          className="w-2 h-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        />
                        <div
                          className="w-2 h-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        />
                      </div>
                    ) : (
                      <>
                        <p className="text-sm mb-3">{chatMessages[currentMessage].ai}</p>

                        {/* Interactive Chart */}
                        <div className="bg-background/50 rounded-lg p-4 border border-primary/20">
                          <div className="flex items-center gap-2 mb-3">
                            {(() => {
                              const ChartIcon = getChartIcon(chatMessages[currentMessage].chart)
                              return <ChartIcon className="w-5 h-5 text-primary" />
                            })()}
                            <span className="text-sm font-medium text-foreground">Interactive Visualization</span>
                          </div>
                          <div className="h-24 bg-gradient-to-r from-primary/30 via-secondary/30 to-primary/30 rounded flex items-center justify-center">
                            <div className="text-sm text-foreground animate-pulse">Live Ocean Data Chart</div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-primary/20">
                <div className="flex gap-2">
                  <div className="flex-1 bg-input rounded-lg p-3 text-sm text-muted-foreground">
                    Ask me anything about ocean data...
                  </div>
                  <Button size="sm" className="px-6">
                    Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
